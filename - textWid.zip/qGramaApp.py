import sys
from PyQt4 import QtGui
import qRemoveQtConf  # функция для удаления вечно появляющегося qt.conf
import aboutinfo  # модуль с данными о программе


class q_grama_app(QtGui.QApplication):

    def __init__(self, args):
        QtGui.QApplication.__init__(self, args)  # инициализация предка
        qRemoveQtConf.removeQtConf()  # удалить qt.conf
        # self.mainTrayIcon = self.createTrayIcon()
        # self.aboutWindow = self.createAbout()
        print(' > Загружено приложение:', aboutinfo.programName, '\n',
              '  Версия:', aboutinfo.version, '\n',
              '  Автор:', aboutinfo.author)


if __name__ == '__main__':
    app = q_grama_app(sys.argv)
    app.exec_()
