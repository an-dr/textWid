import sys  # Для значка в трее
import os  # Для поиска пути до файла


def removeQtConf():
    pathToFile, exeFile = os.path.split(os.path.abspath(sys.executable))
    pathToQtConf = pathToFile + "\qt.conf"
    # print(pathToFile)
    if os.path.isfile(pathToQtConf):
        os.remove(pathToQtConf)
        print("Файл qt.conf удален")
    else:
        print("Нет файла qt.conf")
