# from aboutinfo import *  # модуль с данными о программе
author = "grama"  # автор
programName = "textWid"  # название программы
version = "0.9.5.160326"  # версия программы

if __name__ == '__main__':
    info = programName + '\nv.' + version + '\nby ' + author
    print(info)
    input()
