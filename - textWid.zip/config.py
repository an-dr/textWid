import configControl

# portableMode = True  # портативный режим


def init(portableMode=True):
    configControl.initConfigFile(False, portableMode)  # создаем или проверяем наличие файл конфигурации
    if configControl.readConfigFileValue('main', 'first_start', portableMode) == '0':
        noteTextFilePath = configControl.pathForSettings(portableMode) + 'textWid_note.txt'
        configControl.addOrEditConfigFile('main', 'note_text_file', noteTextFilePath, portableMode)  # автозагрузка
    configControl.addOrEditConfigFile('main', 'first_start', '1', portableMode)  # совершен первый запуск

def main():
    portableMode = True
    init(portableMode)
    configControl.readConfigFileValue('main', 'autostart', portableMode)

if __name__ == '__main__':
    main()
