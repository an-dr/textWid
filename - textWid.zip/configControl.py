import os
import aboutinfo  # модуль с данными о программе
import configparser
# ----настройка модуля
# portableMode = True  #
# ----настройка модуля


configFileName = aboutinfo.programName + '-config.ini'  # путь до файла
config = configparser.ConfigParser()  # для работы с файлом настроек


def pathForSettings(portableMode=True):
    if portableMode is False:
        roamingPath = os.getenv('APPDATA')  # положение папки настроек, переносимых на другой компьютер
        roamingPath = os.path.abspath(roamingPath)  # приводим к универсальному виду
        programFolder = roamingPath + "\\gramaApps\\" + aboutinfo.programName + "\\"
        if os.path.exists(programFolder) is False:
            os.makedirs(programFolder)
    else:
        programFolder = ""
    return programFolder
    # fistFilePath = roamingPath + "\\gramaApps\\hotEges\\firststart"  # предполагаемое положение файла
    # open(fistFilePath, 'w').close()
    # print("Создан файл первого запуска")


def getConfigFilePath(portableMode=True):
    path = pathForSettings(portableMode)
    configFilePath = path + configFileName
    return configFilePath


def initConfigFile(overwrite=False, portableMode=True):
    "Если файл есть, то ничего не делает. Если нет - создает."
    configFilePath = getConfigFilePath(portableMode)
    try:
        with open(configFilePath, 'r') as configfile:
            # configfile.close()
            pass
    except:
        config['main'] = {
            'first_start': '0'
        }
        # config['Other'] = {
        #     'lastWindowX': '0',
        #     'lastWindowY': '0'
        # }
        with open(configFilePath, 'w') as configfile:
            config.write(configfile)
            # configfile.close()
    if overwrite is True:
        config['main'] = {
            'first_start': '0'
        }
        with open(configFilePath, 'w') as configfile:
            config.write(configfile)


def readConfigFileValue(section, variable, portableMode=True):
    configFilePath = getConfigFilePath(portableMode)
    config.read(configFilePath)
    try:
        var = config.get(section, variable)
    except:
        var = 'error'
    print(variable, '=', var)
    return var


def addOrEditConfigFile(section, variable, value, portableMode=True):
    configFilePath = getConfigFilePath(portableMode)  # получаем расположение настроек
    config.read(configFilePath)  # читаем настройки
    try:  # пытаемся добавить значение
        config.set(section, variable, value)
    except:  # если не добавляется, создаем новую секцию и вновь пытаемся
        config.add_section(section)
        config.set(section, variable, value)
    with open(configFilePath, 'w') as configfile:  # записываем в файл
        config.write(configfile)
        # configfile.close()


def main():
    portableMode = False
    # portableMode = True
    initConfigFile(True, portableMode)
    addOrEditConfigFile('123', 'setting 4', 'C:\\Users\\Андрей\\AppData\\Roaming\\gramaApps\\gramaBlank', portableMode)
    # addOrEditConfigFile('Main', 'First start', '1', portableMode)
    # print(readConfigFileValue('DEFAULT', 'setting 4', portableMode))
    # config.read(configFileName)

if __name__ == '__main__':
    main()
