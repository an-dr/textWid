from PyQt4 import QtGui, QtCore, uic
import sys
from resources import *  # для компииляции в exe
from mainActions import *

form_class = uic.loadUiType(textWidUI)[0]  # Загрузка графики из ui


class mainWindows(QtGui.QWidget, form_class):

    def __init__(self, parent=None):
        QtGui.QWidget.__init__(self, parent)
        self.setupUi(self)
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint | QtCore.Qt.SubWindow)  # удаляем рамки | скрываем отображение в таскбаре
        self.plainTextEdit.textChanged.connect(self.writeAllow)
        self.actionTimeout = 5000  # время перед началом записи-чтения
        self.write = False  # разрешение записи
        self.timer_read_write = QtCore.QTimer(parent=None)  # устанавливаем таймер обновления
        self.timer_read_write.timeout.connect(self.read_write)  # СИГНАЛ - переполнение таймера обновления
        self.show()
        # действия:
        self.plainTextEdit.setPlainText(readOrCreateFile())
        self.timer_read_write.start(self.actionTimeout)  # запуск таймера обновления
        # self.toStartup()

    # def keyPressEvent(self, event):
    #     "Переопределяет keyPressEvent"
    # if event.key() == QtCore.Qt.Key_Escape:  # если нажат Escape
    # app.exit()  # скрыть окно

    def mousePressEvent(self, event):
        'Переопределение события нажатия мыши'
        self.offset = event.pos()

    def mouseMoveEvent(self, event):
        'Переопределение события движения мыши'
        x = event.globalX()
        y = event.globalY()
        x_w = self.offset.x()
        y_w = self.offset.y()
        self.move(x - x_w, y - y_w)

    def writeAllow(self):
        self.timer_read_write.stop  # стоп таймера обновления
        self.write = True  # разрешить запись
        self.timer_read_write.start(self.actionTimeout)  # запуск таймера обновления

    def read_write(self):
        if self.write is True:
            writeToFile(self.plainTextEdit.toPlainText())  # запись в файл из plainTextEdit
            self.write = False  # после завершения записи, запретить ее
        else:
            if pressedMouseButton() is False:  # если не нажата какая-то кнопка мыши
                # обработка старого курсора:
                oldCursor = self.plainTextEdit.textCursor()  # полчаем старый курсор
                startPos = oldCursor.selectionStart()  # начало выделения
                endPos = oldCursor.selectionEnd()  # конец выделения
                # чтение:
                self.plainTextEdit.setPlainText(readOrCreateFile())  # читаем
                # обработка нового курсора:
                newCursor = self.plainTextEdit.textCursor()  # берем новый курсор
                newCursor.setPosition(startPos)  # устанавливаем стартовую позицию
                newCursor.setPosition(endPos, QtGui.QTextCursor.KeepAnchor)  # устанавливаем конечную позицию
                self.plainTextEdit.setTextCursor(newCursor)  # применяем новый курсор
                # конец
                logger.debug('Прочитано')
            else:  # если какая-то кнопка мыши нажата
                pass  # ничего неделаем
                logger.debug('Отмена - нажата кнопка мыши')

    # def toStartup(self):
    #     "Добавляет программу в автозагрузку. На вход, показывать или нет сообщения (True/False)"
    #     aKey = winreg.OpenKey(winreg.HKEY_CURRENT_USER, "Software\\Microsoft\\Windows\\CurrentVersion\\Run", 0, (
    # winreg.KEY_WOW64_64KEY + winreg.KEY_ALL_ACCESS))  # Ключ реестра
    #     try:
    # if os.path.dirname(__file__) == os.path.dirname(sys.executable):
    #         exeFilePath = sys.executable
    #         exeFileName = os.path.basename(exeFilePath)
    #         if exeFileName != "python.exe" and exeFileName != "pythonw.exe":
    #             hEpath = '"' + os.path.abspath(sys.executable) + '"'
    #             winreg.SetValueEx(aKey, programName, 0, winreg.REG_SZ, hEpath)
    # print(sys.path)
    # print(os.path.dirname(__file__))
    #             print("Добавлен в автозагрузку")
    # if message is True:
    # self.showMessage(
    # programName, "Added to Startup", icon=1, msecs=1000)
    #         else:
    #             hEpath = '"' + os.path.abspath(__file__) + '"'
    #             winreg.SetValueEx(aKey, programName, 0, winreg.REG_SZ, hEpath)
    #             print("Добавлен в автозагрузку скрипт")
    # if message is True:
    # self.showMessage(
    # programName, "Added to Startup (py\pyw-file)", icon=1, msecs=1000)
    #     except:
    #         print("Не добавлено в автозагрузку")
    # if message is True:
    # self.showMessage(
    # programName, "Don't added to Startup", icon=1, msecs=1000)


if __name__ == "__main__":  # запуск приложения
    app = QtGui.QApplication(sys.argv)
    textWidWindow = mainWindows(None)  # создать окно
    textWidWindow.show()
    app.exec_()
