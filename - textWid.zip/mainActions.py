import logging
# import os
# import sys
# from win32api import keybd_event, GetKeyState  # Для работы с клавишами и получения состояния клавиши
from ctypes import windll  # Для получения положения курсора
# Настроить:
import config
portableMode = False  # работа в портативном режиме

logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)
# def getWorkPath():
#     return getWorkPathAppData()


# def getWorkPathPortable():
#     workpath = ''
#     exeFilePath = sys.executable
#     exeFileName = os.path.basename(exeFilePath)
#     if exeFileName != "python.exe" and exeFileName != "pythonw.exe":
# logger.debug('python.exe')
#         workpath = os.path.dirname(exeFilePath)
#     else:
# logger.debug('not python.exe')
#         workpath = os.path.dirname(__file__)
#     logger.info('workpath = %s', workpath)
#     return workpath


# def getWorkPathAppData():
# roamingPath = os.getenv('APPDATA')  # положение папки настроек, переносимых на другой компьютер
# roamingPath = os.path.abspath(roamingPath)  # приводим к универсальному виду
#     programFolder = roamingPath + "\\gramaApps\\" + programName
#     if os.path.exists(programFolder) is False:
#         os.makedirs(programFolder)
#     workpath = programFolder
#     return workpath


def readOrCreateFile():
    "Читает, либо создает файл"

    # workpath = getWorkPath()
    text_file = config.configControl.readConfigFileValue('main', 'note_text_file', portableMode)
    # logger.debug(text_file)
    try:
        f = open(text_file, 'r')
        text = f.read()
        f.close()
        return text
    except:
        f = open(text_file, 'w')
        text = ''
        f.close()
        return text
    # logger.debug(os.path.abspath(text_file))
    # print(os.path.abspath(f))


def writeToFile(textToWrite):
    text_file = config.configControl.readConfigFileValue('main', 'note_text_file', portableMode)
    f = open(text_file, 'w')
    f.write(textToWrite)
    f.close()


def pressedMouseButton():
    "Проверяет, нажата ли одна из пяти кнопок мыши"

    mouseButton1 = windll.user32.GetAsyncKeyState(1)
    mouseButton2 = windll.user32.GetAsyncKeyState(2)
    mouseButton3 = windll.user32.GetAsyncKeyState(3)
    mouseButton4 = windll.user32.GetAsyncKeyState(4)
    mouseButton5 = windll.user32.GetAsyncKeyState(5)
    if mouseButton1 != 0 or mouseButton2 != 0 or mouseButton3 != 0 or mouseButton4 != 0 or mouseButton5 != 0:
        someButtonIsPressed = True
    else:
        someButtonIsPressed = False
    # print(mouseButton1)
    # print(mouseButton2)
    # print(mouseButton3)
    # print(mouseButton4)
    # print(mouseButton5)
    return someButtonIsPressed


def main():
    config.init()

if __name__ == '__main__':
    main()
    input()
