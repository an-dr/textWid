import sys  # Для значка в трее
from resources import *
from PyQt4 import QtGui, QtCore
# from qAbout import *  # импорт "О программе"


class q_grama_tray_icon(QtGui.QSystemTrayIcon):

    def __init__(self, icon, parent=None):
        "На вход нужно - приложение(для управления), иконка"
        qIcon = QtGui.QIcon(icon)  # иконка
        QtGui.QSystemTrayIcon.__init__(self, qIcon, parent)  # инициализация родителя
        self.qApp = QtCore.QCoreApplication.instance()  # - это доступ к главному экземляру приложения Qt
        self.show()  # отобразить иконку
        self.trayMenu = QtGui.QMenu(parent)  # создать объект контекстного меню
        self.setContextMenu(self.trayMenu)  # привязать контекстное меню к иконке в трее
        self.setToolTip("a grama App")  # всплывающая подсказка
        # self.aboutWindow = aboutWindows(None)  # создать окно О программе
        # Настройка меню:
        # self.about.triggered.connect(self.aboutWindowShow)  # СИГНАЛ - нажатие на строку о программе
        self.exitAction = self.trayMenu.addAction("Exit")  # добавить в контекстное меню
        self.exitAction.triggered.connect(self.closeApp)  # СИГНАЛ - нажатие на строку выхода

    # def aboutWindowShow(self):
    #     try:
    #         aboutWindow.show()
    #     except:
    #         print("Нет окна О приложении")

    def closeApp(self):
        print("Closing...")
        self.qApp.exit()  # выход


if __name__ == "__main__":  # запуск приложения
    app = QtGui.QApplication(sys.argv)
    iconTray = q_grama_tray_icon(icon_tray_png)  # создать иконку в трее
    app.exec_()
    # sys.exit(app.exec_())
