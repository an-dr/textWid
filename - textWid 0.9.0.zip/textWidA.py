import logging
import os
import sys

programName = "textWid"

logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)


def getWorkPath():
    return getWorkPathAppData()


def getWorkPathPortable():
    workpath = ''
    exeFilePath = sys.executable
    exeFileName = os.path.basename(exeFilePath)
    if exeFileName != "python.exe" and exeFileName != "pythonw.exe":
        # logger.debug('python.exe')
        workpath = os.path.dirname(exeFilePath)
    else:
        # logger.debug('not python.exe')
        workpath = os.path.dirname(__file__)
    logger.info('workpath = %s', workpath)
    return workpath


def getWorkPathAppData():
    roamingPath = os.getenv('APPDATA')  # положение папки настроек, переносимых на другой компьютер
    roamingPath = os.path.abspath(roamingPath)  # приводим к универсальному виду
    programFolder = roamingPath + "\\gramaApps\\" + programName
    if os.path.exists(programFolder) is False:
        os.makedirs(programFolder)
    workpath = programFolder
    return workpath


def readOrCreateFile():
    "Читает, либо создает файл"
    workpath = getWorkPath()
    textFile = workpath + "\widtxt"
    # logger.debug(textFile)
    try:
        f = open(textFile, 'r')
        text = f.read()
        f.close()
        return text
    except:
        f = open(textFile, 'w')
        text = ''
        f.close()
        return text
    # logger.debug(os.path.abspath(textFile))
    # print(os.path.abspath(f))


def writeToFile(textToWrite):
    workpath = getWorkPath()
    textFile = workpath + "\widtxt"
    f = open(textFile, 'w')
    f.write(textToWrite)
    f.close()


def main():
    text = readOrCreateFile()
    logger.debug(text)
    textToWrite = "1231231"
    writeToFile(textToWrite)

if __name__ == '__main__':
    main()
    input()
